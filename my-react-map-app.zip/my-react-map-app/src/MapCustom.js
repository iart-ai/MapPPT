import React, { useState, useEffect, useRef } from 'react';
import DeckGL from '@deck.gl/react';
import { createStructuredOutputRunnable } from "langchain/chains/openai_functions";
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { JsonOutputFunctionsParser } from "langchain/output_parsers";

import ReactMapGL, { MapboxMap } from 'react-map-gl';
// import geoJsonPath from './gaza.geojson';
import geoJsonPath from './IMSR_Incident_Locations_ViewA_Final_Occurrence.geojson'
import * as turf from '@turf/turf';
import { PolygonLayer } from '@deck.gl/layers';
import { GeoJsonLayer } from '@deck.gl/layers';
import { ScatterplotLayer } from '@deck.gl/layers';

import { TextLayer } from '@deck.gl/layers';
import nlp from 'compromise';
import MapboxMapCustom from './MapboxMapCustom';
import { FaSearch } from 'react-icons/fa';
// import Select from 'react-select'; // 假设使用 react-select 作为下拉菜单
// 解析 GeoJSON 数据以获取坐标
import { FlyToInterpolator } from '@deck.gl/core';
import OpenAI from "openai";
const openai = new OpenAI({
    //   apiKey: process.env.OPENAI_API_KEY,
    apiKey: "sk-",
    dangerouslyAllowBrowser: true
});



async function sendToOpenAI(inputText) {
    try {
        const chatCompletion = await openai.chat.completions.create({
            messages: [
                { role: "user", content: inputText }],
            model: "gpt-3.5-turbo",
            // model:"gpt-4-0314",
        });

        const responseText = chatCompletion?.choices[0]?.message?.content || "";


        // Extract and return the text from the response
        return responseText;
    } catch (error) {
        console.error("Error communicating with OpenAI:", error);
        return "Sorry, I couldn't process that.";
    }
}


// 地图的初始视图状态
const initialViewState = {
    longitude: 9.6659,
    latitude: 48.1627,
    zoom: 10,
    pitch: 0,
    bearing: 0
};

function getFirstCoordinate(coordinates) {
    // Return the first set of coordinates from the data.
    // Assuming that 'coordinates' is an array of arrays like [[lon, lat], [lon, lat], ...].
    if (coordinates.length > 0 && coordinates[0].length > 0) {
        return { longitude: coordinates[0][0], latitude: coordinates[0][1] };
    }
    return { longitude: 0, latitude: 0 }; // Default to (0,0) if no coordinates are present.
}



function getCentroid(coordinates) {
    let validCoordinates = coordinates.filter(coord => coord && coord.length >= 2 && !isNaN(coord[0]) && !isNaN(coord[1]));

    // 如果没有有效坐标，则返回一个默认值或第一个坐标
    if (validCoordinates.length === 0) {
        return coordinates[0] && coordinates[0].length >= 2
            ? { longitude: coordinates[0][0][0], latitude: coordinates[0][0][1] }
            : { longitude: 0, latitude: 0 }; // 或者返回一个全局的默认位置
    }

    let centroid = { longitude: 0, latitude: 0 };
    validCoordinates.forEach(coord => {
        centroid.longitude += coord[0];
        centroid.latitude += coord[1];
    });

    centroid.longitude /= validCoordinates.length;
    centroid.latitude /= validCoordinates.length;

    return centroid;
}


const MapCustom = () => {
    const [eventDescription, setEventDescription] = useState('');
    const [combinedDetails, setCombinedDetails] = useState('');

    const [chatInput, setChatInput] = useState('');
    const [viewState, setViewState] = useState(initialViewState);
    const [boundaryData, setBoundaryData] = useState([]);
    const [layers, setLayers] = useState([]);
    const [mentionedLocations, setMentionedLocations] = useState([]);
    const [eventDetails, setEventDetails] = useState([]);
    const [pointSize, setPointSize] = useState(1); // 默认点的大小
    const [pointColor, setPointColor] = useState([0, 0, 0]); // 默认颜色
    const [pointOpacity, setPointOpacity] = useState(100); // 默认透明度
    const eventDetailsRef = useRef(null);
    const cityNames = ['Nanjing', 'Beijing', 'Shanghai', 'Wuhan', 'Chongqing', 'Changsha', 'Guangxi', 'Shaanxi', 'Henan'];
    const text = `
    Wiki page for Second Sino-Japanese War

    Introduction: 
    The Second Sino-Japanese War, also known in Japan as the Second China–Japan War,  and in China as the Chinese War of Resistance against Japanese  Aggression, was fought between the Republic of China and the Empire of Japan from 1937 to 1945 as part of World War II. It is often  regarded as the beginning of World War II in Asia, though some  scholars consider the European War and Pacific War to be separate,  albeit concurrent. It was the largest Asian war in the 20th  century and has been described as 'the Asian Holocaust',  in reference to the scale of Japanese war crimes against Chinese  civilians.
      
    Trigger: 
    The Marco Polo Bridge incident on 7 July 1937 is viewed as the start of the Second Sino-Japanese War, though some historians consider the 18 September 1931 Mukden Incident, the  pretext that Japan fabricated to justify their invasion of Manchuria, to mark the beginning. During the invasion, China was aided by the Soviet Union, the United Kingdom, the United States, and Nazi Germany before Germany allied with Japan. From 1931 to 1937, there were skirmishes between China and Japan in China. Following the bridge incident, a dispute between Chinese and Japanese troops in Beijing, the conflict escalated into a full-scale Japanese invasion of the rest of China. Japan achieved major victories, capturing Beijing and Shanghai by 1937. Having fought each other in the Chinese Civil War since 1927, the Communists and Nationalists formed the Second United Front in late 1936 to resist the Japanese invasion together.
    
    Main events:
    The Japanese captured the Chinese capital of Nanjing in 1937, which led to the Nanjing Massacre, also known as the Rape of Nanjing. After failing to stop the Japanese in the Battle of Wuhan, the Chinese central government relocated to Chongqing in the Chinese interior. Following the Sino-Soviet Non-Aggression Pact, material support bolstered the Republic of China Army and Air Force. By 1939, after Chinese victories in Changsha and Guangxi, and with Japan's lines of communications stretched deep into the Chinese interior, the war reached a stalemate. The Japanese were unable to defeat Chinese Communist Party (CCP) forces in Shaanxi, who waged a campaign of sabotage and guerrilla warfare. In November 1939, Chinese nationalist forces launched a large scale winter offensive, and in August 1940, CCP forces launched an offensive in central China. In December 1941, Japan launched its surprise attack on Pearl Harbor and declared war on the United States. The US increased aid to China: the Lend-Lease act gave China a total of $1.6 billion ($20 billion 2023). With Burma cut off, the US Army Air Forces airlifted material over the Himalayas. In 1944, Japan launched Operation Ichi-Go, the invasion of Henan and Changsha. In 1945, the Chinese Expeditionary Force resumed its advance in Burma and completed the Ledo Road linking India to China. China launched large counteroffensives in South China and repulsed a failed Japanese invasion of West Hunan and recaptured Japanese occupied regions of Guangxi.\
    
    Results:
    Japan formally surrendered on 2 September 1945, following the atomic bombings of Hiroshima and Nagasaki, Soviet declaration of war and invasions of Manchukuo and Korea. The war resulted in the deaths of around 20 million people, mostly civilians. China was recognized as one of the Big Four Allies, regained all territories lost, and became one of the five permanent members of the United Nations Security Council. The Chinese Civil War resumed in 1946, ending with a communist victory, which established the People's Republic of China.`
    // 分割段落并渲染文本
    // const renderTextWithParagraphs = (text, cityNames) => {
    //     // 直接使用 '\n' 来分割文本，而不是使用正则表达式的转义字符
    //     const paragraphs = text.split('\n');
    //     return paragraphs.map((paragraph, index) => (
    //         <p key={index} style={{ fontSize: '20px', whiteSpace: 'pre-line' }}>
    //             {paragraph.split(' ').map((word, wordIndex) => {
    //                 const cityName = cityNames.find(city => word.includes(city));
    //                 const key = `${index}-${wordIndex}`;
    //                 return (
    //                     <React.Fragment key={key}>
    //                         {cityName ? (
    //                             <span
    //                                 style={{ cursor: 'pointer', textDecoration: 'underline', fontSize: '20px' }}
    //                                 onClick={() => handleFixCityClick(cityName)}>
    //                                 {word}
    //                             </span>
    //                         ) : word}
    //                         {' '} {/* 添加空格 */}
    //                     </React.Fragment>
    //                 );
    //             })}
    //         </p>
    //     ));
    // };
    const fetchEventDetails = async () => {
        const jsonSchema = {
            title: "EventDetails",
            description: `You are a Wikipedia writer.
                  You have gathered information from experts and search engines.
                  Now, you are refining the outline and detail of the Wikipedia page.
                  Write an outline and detail for a Wikipedia page about the user-provided topic: Be comprehensive and specific.
                  
                  Structure your response as follows:
                  Event1: [Event Name]
                  Location1: [Specific City ], [Country]
                  Date1: [Month Day, Year] or [Month Day, Year - Month Day, Year]
                  Background1: [Background information related to the event ]
                  MainEvent1: [Key actions or occurrences in the event]
                  Result1: [Outcome or conclusion of the event]
                  Description1: [Detailed explanation of the event's direct connection and significance to the event ]
                  You need to generate more than 5 examples.
                  `,
            type: "object",  // 确保最外层是 object 类型
            properties: {
                events: {  // 使用一个数组属性来存储多个事件
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            city: { type: "string" },
                            country: { type: "string" },
                            date: { type: "string" },
                            background: { type: "string" },
                            mainEvent: { type: "string" },
                            result: { type: "string" },
                            description: { type: "string" },
                        },
                        required: ["city", "country", "date", "background", "mainEvent", "result", "description"],
                    },
                },
            },
            required: ["events"],
        };

        const model = new ChatOpenAI({ openAIApiKey: "sk-", });

        const prompt = ChatPromptTemplate.fromMessages([
            ["human", "Event description: {description}"],
        ]);

        const outputParser = new JsonOutputFunctionsParser();

        const runnable = createStructuredOutputRunnable({
            outputSchema: jsonSchema,
            llm: model,
            prompt,
            outputParser
        });

        const response = await runnable.invoke({ description: eventDescription });
        console.log("response", response)
        // setEventDetails(response.events);
        return response.events;
    };

    const handleChatSubmit = async (e) => {
        e.preventDefault();
        // const prompt = `You are a Wikipedia writer.
        // You have gathered information from experts and search engines.
        // Now, you are refining the outline and detail of the Wikipedia page.
        // Write an outline and detail for a Wikipedia page about the user-provided topic: "${chatInput}". Be comprehensive and specific.

        // Structure your response as follows:
        // Event1: [Event Name]
        // Location1: [Specific City within "${chatInput}"], [Country]
        // Date1: [Month Day, Year] or [Month Day, Year - Month Day, Year]
        // Background1: [Background information related to the event and "${chatInput}"]
        // MainEvent1: [Key actions or occurrences in the event]
        // Result1: [Outcome or conclusion of the event]
        // Description1: [Detailed explanation of the event's direct connection and significance to "${chatInput}"]

        // Event2: [Event Name]
        // Location2: [Specific City within "${chatInput}"], [Country]
        // Date2: [Month Day, Year] or [Month Day, Year - Month Day, Year]
        // Background2: [Background information related to the event and "${chatInput}"]
        // MainEvent2: [Key actions or occurrences in the event]
        // Result2: [Outcome or conclusion of the event]
        // Description2: [Detailed explanation of the event's direct connection and significance to "${chatInput}"]

        // [Continue with more events as needed]
        // Please generate more than 10 events, ensuring all events and locations are strictly relevant to "${chatInput}". The locations should be city names, not specific regions. In the descriptions, ensure logical progression, using phrases like 'First', 'Second', etc.`
        // const newUserMessage = { sender: 'user', text: chatInput };
        // // setEventDetails([...eventDetails, newUserMessage]);
        // console.log("chatInput", prompt)
        // // 发送prompt到ChatGPT
        // const response = await sendToOpenAI(prompt);
        // console.log("Response from ChatGPT: ", response);

        // // 处理返回的信息，并存储到状态中
        // const eventsFromChat = await parseEventsFromResponse(response);
        const newUserMessage = {
            sender: 'user',
            text: eventDescription
        };

        // 既然我们在上面的逻辑中已经使用了 LangChain API 来获取事件细节
        // 我们假设 response 已经包含了所有需要的事件信息
        const eventsFromChat = await fetchEventDetails();
        // console.log("eventDetails in the handle", eventsFromChat)

        const aiMessages = eventsFromChat.map(event => ({
            ...event,
            sender: 'ai', // 标记为AI发送的信息
        }));
        setEventDetails([...eventDetails, newUserMessage, ...aiMessages]);
        console.log("event details in handle ", eventDetails)
        setEventDescription('');
    };

    function extractCityNames(text) {
        let doc = nlp(text);
        let places = doc.places().out('array'); // 提取地点名称
        return places;
    }

    const [geoJsonData, setGeoJsonData] = useState(null);
    useEffect(() => {
        fetch(geoJsonPath)
            .then(response => response.json())
            .then(data => {
                setGeoJsonData(data);
                console.log("setGeoJsonData", data); // 现在你可以看到实际的 GeoJSON 数据了
            })
            .catch(error => console.error('Error loading GeoJSON data:', error));
    }, []);

    const parseEventsFromResponse = async (response) => {
        const eventSections = response.split('\n\n').filter(section => section.trim() !== '');
        const events = [];


        for (const section of eventSections) {
            const details = section.split('\n').filter(line => line.includes(':'));
            let cityNames = [], country = '', date = '', description = '', result = '', mainEvent = '', background = '', eventname = '';
            let additionalLocations = [];

            for (const detail of details) {
                const [key, value] = detail.split(':').map(part => part.trim());
                if (!value) continue;

                if (key.toLowerCase().startsWith('location')) {
                    const parts = value.split(',');
                    // console.log("parts", parts)
                    if (parts.length > 1) {
                        country = parts.pop().trim(); // 取最后一部分作为国家

                        const firstCity = parts[0]
                        // 检查是否存在边界数据
                        const boundary = await fetchBoundaryData(firstCity);
                        if (boundary && boundary.data && boundary.data.coordinates) {
                            cityNames.push(firstCity);
                        }
                    }
                } else if (key.toLowerCase().startsWith('date')) {
                    date = value;
                } else if (key.toLowerCase().startsWith('description')) {
                    description = value;
                    // 使用某个函数提取描述中的地理位置信息
                    additionalLocations = extractCityNames(description);
                } else if (key.toLowerCase().startsWith('background')) {
                    background = value;
                } else if (key.toLowerCase().startsWith('mainevent')) {
                    mainEvent = value;
                } else if (key.toLowerCase().startsWith('result')) {
                    result = value;
                } else if (key.toLowerCase().startsWith('event')) {
                    eventname = value;
                }
            }
            for (const city of cityNames) {
                events.push({
                    city,
                    country,
                    date,
                    eventname,
                    description,
                    additionalLocations,
                    background, // 这些应该根据实际的解析结果来填充
                    mainEvent,
                    result
                });
                console.log("events", events)

            }
        }

        return events;
    };



    const fetchBoundaryData = async (location) => {
        // 这里过滤本地GeoJSON数据以找到与 location 匹配的特征
        try {
            const apiBaseUrl = 'https://still-ravine-97463-ab61cc4df1cf.herokuapp.com';
            const response = await fetch(`${apiBaseUrl}/getBoundary?location=${encodeURIComponent(location)}`);
            if (!response.ok) {
                throw new Error(`Error fetching boundary data for ${location}: ${response.statusText}`);
            }
            const data = await response.json();
            // return data;
            console.log("data in fetchBoundaryData", data)
            return { location, data };
        } catch (error) {
            console.error('Error fetching local GeoJSON data:', error);
            // return [];
            return { location, data: null };
        }
    };




    useEffect(() => {
        // 假设 scatterplotLayer 和 geoJsonLayer 是你已经定义好的图层
        let baseLayers = [];
        if (geoJsonData && geoJsonData.features) { //

            const geoJsonLayer = new GeoJsonLayer({
                id: 'geojson-layer',
                data: geoJsonData, // Your GeoJSON data
                pickable: true,
                stroked: false,
                filled: true,
                extruded: true,
                pointRadiusScale: 2,
                getFillColor: [160, 160, 180, 200],
                // getLineColor: d => d.properties.color ? colorToRGBArray(d.properties.color) : [0, 0, 0],
                getLineColor: [0, 0, 0],
                getRadius: d => d.properties.radius,
                getLineWidth: 1,
                getElevation: d => d.properties.value * 30,
            });

            const scatterplotLayer = new ScatterplotLayer({
                id: 'scatterplot-layer',
                data: geoJsonData.features.filter(f => f.geometry.type === "Point"),
                getPosition: d => d.geometry.coordinates,
                getRadius: d => d.properties.size * pointSize || 1000, // 使用 properties.size 定义大小，或默认值1000
                getFillColor: [...pointColor, pointOpacity],
                getLineColor: [0, 0, 0],
                pickable: true,
            });

            setLayers(oldLayers => [...oldLayers, geoJsonLayer, scatterplotLayer]);
            baseLayers = [geoJsonLayer, scatterplotLayer];

        }

        if (eventDetails.length > 0) {
            const createdLayers = new Set();
            const newLayers = eventDetails.reduce((acc, event) => {
                // 确认数据存在并且格式正确
                if (!createdLayers.has(event.city) && event.boundary && event.boundary.data && Array.isArray(event.boundary.data.coordinates)) {
                    const coordinates = event.boundary.data.coordinates[0][0];
                    if (coordinates && coordinates.every(coord => Array.isArray(coord) && coord.length === 2)) {
                        // 创建新图层
                        const layer = new PolygonLayer({
                            id: `event-boundary-${event.city.replace(/\s/g, '-')}`, // 确保id是唯一的并且没有空格
                            data: [{ coordinates: coordinates }], // 确保数据是期望的格式
                            pickable: true,
                            stroked: true,
                            filled: true,
                            lineWidthMinPixels: 1,
                            getPolygon: d => d.coordinates,
                            getFillColor: [255, 0, 0, 100], // 使用固定的颜色或根据需要动态设置
                            getLineColor: [255, 255, 255],
                            getLineWidth: 1,
                        });
                        acc.push(layer);
                        createdLayers.add(event.city); // 将城市添加到已创建集合

                    } else {
                        console.error(`Invalid boundary data for ${event.city}`);
                    }

                }
                return acc;
            }, baseLayers);
            setLayers(newLayers); // 更新图层
        }
    },
        [eventDetails, geoJsonData, pointSize, pointColor, pointOpacity]); // 依赖于eventDetails变化


    function hexToRGB(hex) {
        let r = 0, g = 0, b = 0;
        // 3 digits
        if (hex.length === 4) {
            r = parseInt(hex[1] + hex[1], 16);
            g = parseInt(hex[2] + hex[2], 16);
            b = parseInt(hex[3] + hex[3], 16);
        }
        // 6 digits
        else if (hex.length === 7) {
            r = parseInt(hex[1] + hex[2], 16);
            g = parseInt(hex[3] + hex[4], 16);
            b = parseInt(hex[5] + hex[6], 16);
        }
        return [r, g, b];
    }
    useEffect(() => {
        // 这个 useEffect 可以用来检查 layers 状态变化后的逻辑
        console.log("Layers updated:", layers);
        // 这里可以添加任何依赖于 layers 更新的逻辑
    }, [layers]); // 依赖数组中包含 layers，以便当 layers 更新时触发这个 useEffect

    const handleFixCityClick = async (cityName) => {
        // let boundary = boundaryData.find(b => b.location === cityName);
        let boundary = boundaryData[cityName];
        if (!boundary) {
            boundary = await fetchBoundaryData(cityName);

            if (!boundary || !boundary.data || !boundary.data.coordinates) {
                console.log(`本地API未找到 ${cityName} 的边界数据，尝试Google Maps API...`);
                boundary = await fetchGoogleMapsData(cityName);
            }

            if (boundary && boundary.data && boundary.data.coordinates) {
                setBoundaryData([...boundaryData, boundary]);
            } else {
                console.error(`未找到 ${cityName} 的边界数据`);
                return;
            }
        }

        // 更新eventDetails中对应事件的boundary
        const updatedEventDetails = eventDetails.map(event => {
            if (event.city === cityName) {
                return { ...event, boundary: boundary };
            }
            return event;
        });

        setEventDetails(updatedEventDetails);

        // 如果需要，更新视图状态
        const coordinates = boundary.data.coordinates[0];
        const centroid = getCentroid(coordinates);
        setViewState({
            ...viewState,
            longitude: centroid.longitude,
            latitude: centroid.latitude,
            zoom: 9,
            transitionDuration: 1000,
            transitionInterpolator: new FlyToInterpolator(),
        });
        const new_coordinates = boundary.data.coordinates[0][0];

        const boundaryLayer = new PolygonLayer({
            id: `boundary-${cityName}`,
            data: [{ coordinates: new_coordinates }],
            getPolygon: d => d.coordinates,
            filled: true,
            stroked: true,
            getFillColor: [255, 0, 0, 100],
            getLineColor: [255, 255, 255],
            lineWidthMinPixels: 1,
        });
        setLayers(prevLayers => {
            // 移除同一城市的旧图层（如果存在）
            // console.log("Before setting layers:", prevLayers);
            const filteredLayers = prevLayers.filter(layer => layer.id !== boundaryLayer.id);
            // return [...filteredLayers, boundaryLayer];
            const newLayers = [...filteredLayers, boundaryLayer];
            // console.log("After setting layers:", newLayers);
            return newLayers;
        });
        // console.log("Before setting layers:", prevLayers);
        // const newLayers = [...filteredLayers, boundaryLayer];
        // console.log("After setting layers:", newLayers);
        // return newLayers;

    };
    const fetchAndGenerateDetails = async () => {
        // JSON Schema 和 LangChain 调用逻辑来获取事件详情...

        // 假设 `fetchEventDetails` 函数已经执行，并且我们现在有了所有事件的数据
        const allEventsDetails = eventDetails.map(event =>
            `${event.city}, ${event.country} on ${event.date}: ${event.description}`
        ).join(' ');

        const model = new ChatOpenAI({ openAIApiKey: "sk-", });

        const comprehensivePrompt = `Given these events: ${allEventsDetails}, describe the overall background, the sequence of events, and the consequences connecting these events.`;

        const prompt = ChatPromptTemplate.fromMessages([
            ["system", comprehensivePrompt]
        ]);

        const outputSchema = {
            title: "ComprehensiveEventDetails",
            description: "A comprehensive description covering all events and their connections.",
            type: "object",  // 输出是一个对象
            properties: {
                comprehensiveDescription: {  // 这个属性将包含综合描述
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            background: { type: "string" },
                            sequence: { type: "string" },
                            description: { type: "string" },
                            result: { type: "string" },
                        },
                        required: ["background", "sequence", "description", "result"]
                    }
                    // description: "A detailed description of all events and their interrelations."
                }
            },
            required: ["comprehensiveDescription"]  // 这个属性是必需的
        };
        const outputParser = new JsonOutputFunctionsParser();
        const runnable = createStructuredOutputRunnable({
            outputSchema: outputSchema,
            llm: model,
            prompt,
            outputParser
        });

        // 使用 LangChain 生成综合背景和结果描述
        const response = await runnable.invoke({ description: comprehensivePrompt });
        console.log("response from the generation result", response)
        setCombinedDetails(response.comprehensiveDescription);
    };


    const handleCityClick = async (cityName) => {
        // let boundary = boundaryData.find(b => b.location === cityName);
        let boundary = boundaryData[cityName];
        if (!boundary) {
            boundary = await fetchBoundaryData(cityName);

            if (!boundary || !boundary.data || !boundary.data.coordinates) {
                console.log(`本地API未找到 ${cityName} 的边界数据，尝试Google Maps API...`);
                boundary = await fetchGoogleMapsData(cityName);
            }

            if (boundary && boundary.data && boundary.data.coordinates) {
                setBoundaryData([...boundaryData, boundary]);
            } else {
                console.error(`未找到 ${cityName} 的边界数据`);
                return;
            }
        }

        // 更新eventDetails中对应事件的boundary
        const updatedEventDetails = eventDetails.map(event => {
            if (event.city === cityName) {
                return { ...event, boundary: boundary };
            }
            return event;
        });

        setEventDetails(updatedEventDetails);
        console.log("boundary", boundary)

        // 如果需要，更新视图状态
        const coordinates = boundary.data.coordinates[0];
        const centroid = getCentroid(coordinates);
        setViewState({
            ...viewState,
            longitude: centroid.longitude,
            latitude: centroid.latitude,
            zoom: 9,
            transitionDuration: 1000,
            transitionInterpolator: new FlyToInterpolator(),
        });

    };

    const fetchGoogleMapsData = async (cityName) => {
        try {
            const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(cityName)}&language=en&key=AIzaSyAS9CH6yad241WgPnJu4RvQBobdB3BQQ58`);
            const data = await response.json();

            if (data.status === 'OK' && data.results.length > 0) {
                // 从 Google Maps API 返回的数据中获取地址组件
                const addressComponents = data.results[0].address_components;

                // 检查是否有足够的地址组件
                if (addressComponents.length > 1) {
                    const areaName = addressComponents[1].long_name; // 获取第二个地址组件的长名称
                    console.log("areaName", areaName)
                    // 使用这个区域名称来调用 fetchBoundaryData
                    const boundary = await fetchBoundaryData(areaName);
                    return boundary;
                } else {
                    console.error(`Google Maps API返回的地址组件不足以确定区域: ${cityName}`);
                    return { data: null };
                }
            } else {
                console.error(`Google Maps API未找到 ${cityName} 的数据`);
                return { data: null };
            }
        } catch (error) {
            console.error('请求Google Maps API时出错:', error);
            return { data: null };;
        }
    };
    function parseDescriptionForLocations(description, additionalLocations, clickHandler) {
        if (!additionalLocations || additionalLocations.length === 0) {
            return <span>{description}</span>;
        }

        // 创建一个匹配所有城市名称的正则表达式
        const citiesRegex = new RegExp(additionalLocations.join('|'), 'g');

        // 分割description，保留城市名称和其他文本
        const parts = description.split(citiesRegex);

        return parts.map((part, index) => {
            // 检查这部分是否是城市名称
            if (additionalLocations.includes(part)) {
                // 如果是城市名称，则创建一个可点击的元素
                return (
                    <span key={index} onClick={() => clickHandler(part)} style={{ cursor: 'pointer', textDecoration: 'underline' }}>
                        {part}
                    </span>
                );
            } else {
                // 如果不是城市名称，只返回普通文本
                return <span key={index}>{part}</span>;
            }
        });
    }

    const renderEventDetails = () => {
        // console.log("eventDetails in renderEventDetails", eventDetails)

        return (
            <div
                ref={eventDetailsRef}
                style={{ overflowY: 'auto', maxHeight: '100vh' }}
            // style={{
            //     display: 'flex',
            //     flexDirection: 'column',
            //     marginBottom: '20px',
            //     alignItems: 'flex-start', // 对齐到左侧
            //     backgroundColor: '#f0f0f0',
            //     borderRadius: '10px',
            //     maxWidth: '60%', // 控制宽度以形成气泡效果
            //     padding: '10px',
            // }}
            >
                {eventDetails.map((event, index) => (
                    <div
                        key={index}
                        data-city-name={event.city}
                        onMouseOver={() => handleCityHover(event.city)} // 添加这个事件处理函数
                        style={{
                            marginBottom: '10px', // 在事件之间添加间隔
                        }}>
                        {event.sender === 'user' ? (
                            <div style={{
                                backgroundColor: '#007bff',
                                color: 'white',
                                padding: '10px',
                                borderRadius: '10px',
                            }}>
                                {event.text}
                            </div>
                        ) : (

                            // <p>
                            //     {event.city && (
                            //         <span style={{ fontWeight: 'bold', cursor: 'pointer', textDecoration: 'underline' }}
                            //             onClick={() => handleCityClick(event.city)}>
                            //             {event.city}
                            //         </span>

                            //     )}
                            //     {<span>&nbsp;in&nbsp;{event.country}&nbsp;</span>}
                            //     {parseDescriptionForLocations(event.description, event.additionalLocations, handleCityClick)}
                            // </p>
                            <div>
                                {/* <p><strong>Event:</strong> {event.eventname}</p> 确保这里使用正确的属性名来显示事件名称 */}

                                <p>
                                    {event.city && (
                                        <span style={{ fontWeight: 'bold', cursor: 'pointer', textDecoration: 'underline' }}
                                            onClick={() => handleCityClick(event.city)}>
                                            {event.city}
                                        </span>
                                    )}
                                    {<span>&nbsp;in&nbsp;{event.country}&nbsp;</span>}
                                </p>
                                <p><strong>Date:</strong> {event.date}</p>
                                <p><strong>Background and Result:</strong> {event.background} And as a result, {event.result}</p>
                                <p><strong>Description:</strong> {event.description}</p>
                                <hr /> {/* 这里添加了一个水平线作为分割 */}
                            </div>
                        )}

                    </div>
                ))}
                {eventDetails.length > 0 && (
                <button onClick={fetchAndGenerateDetails}>Get Combined Event Details</button>
            )}

            {combinedDetails && combinedDetails.map((detail, index) => (
                <div key={index}>
                    <h2>Overall information</h2>
                    <p><strong>Background:</strong> {detail.background}</p>
                    <p><strong>Sequence of Events:</strong> {detail.sequence}</p>
                    <p><strong>Description:</strong> {detail.description}</p>
                    <p> <strong>Result:</strong> {detail.result}</p>
                </div>
            ))}
                
            </div>
        );
    };
    useEffect(() => {
        // Assuming eventDetails is already populated with the necessary city names
        eventDetails.forEach(event => {
            if (event.city && !boundaryData[event.city]) {
                fetchBoundaryData(event.city).then(data => {
                    setBoundaryData(prevData => ({ ...prevData, [event.city]: data }));
                });
            }
        });
    }, [eventDetails]);

    const handleCityHover = async (cityName) => {
        // 这里你需要找到城市名称对应的地理坐标，这可能是通过搜索你的`boundaryData`数组
        // 或者如果你有城市的坐标直接储存在事件详情中
        let boundary = boundaryData[cityName];
        // let boundary = boundaryData.find(b => b.location === cityName);
        if (!boundary) {
            // If the boundary data is not pre-fetched, fetch it on hover (though ideally, it should be preloaded)
            boundary = await fetchBoundaryData(cityName);
            setBoundaryData(prevData => ({ ...prevData, [cityName]: boundary }));
        }

        if (boundary && boundary.data && boundary.data.coordinates) {
            const coordinates = boundary.data.coordinates[0][0];
            const centroid = getCentroid(coordinates);


            const updatedEventDetails = eventDetails.map(event => {
                if (event.city === cityName) {
                    return { ...event, boundary: boundary };
                }
                return event;
            });

            setEventDetails(updatedEventDetails);
            // 更新视图状态以跳转到该地理位置
            setViewState({
                ...viewState,
                longitude: centroid.longitude,
                latitude: centroid.latitude,
                zoom: 9,
                transitionDuration: 1000,
                transitionInterpolator: new FlyToInterpolator(),
            });
        }
    };



    return (

        <div style={{ display: 'flex', height: '100vh', flexWrap: 'nowrap' }}>

            <div style={{ flex: '1 1 60%', minHeight: '100vh', position: 'relative' }}>
                <DeckGL
                    initialViewState={initialViewState}
                    viewState={viewState}
                    onViewStateChange={({ viewState }) => setViewState(viewState)}
                    controller={true}
                    layers={layers}
                >
                    <ReactMapGL
                        mapboxApiAccessToken={process.env.REACT_APP_MAPBOX_ACCESS_TOKEN}
                        mapStyle="mapbox://styles/mapbox/light-v11"
                    // onHover={handleHover}
                    />

                    {/* 点的大小 */}
                    <div style={{ position: 'absolute', top: 10, left: 10, padding: '10px', backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>

                        <div>
                            <label>Point Size: </label>
                            <input
                                type="number"
                                value={pointSize}
                                onChange={(e) => setPointSize(Number(e.target.value))}
                            />
                        </div>

                        {/* 点的颜色（这里简化为只选择红色通道，你可以扩展为选择RGB各通道） */}
                        <div>
                            <label>Point Color (R value): </label>
                            <input type="color" onChange={(e) => setPointColor([...hexToRGB(e.target.value), pointColor[3]])} />
                        </div>

                        {/* 点的透明度 */}
                        <div>
                            <label>Point Opacity: </label>
                            <input
                                type="range"
                                min="0"
                                max="255"
                                value={pointOpacity}
                                onChange={(e) => setPointOpacity(Number(e.target.value))}
                            />
                        </div>
                    </div>
                </DeckGL>
            </div>
            {/* <div style={{ flex: '1 1 40%', padding: '20px', background: '#f7f7f7', borderRadius: '10px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', margin: '20px', overflowY: 'auto', maxHeight: '100vh' }}> */}
            {/* <p>
                    {words.map((word, index) => {
                        // 检查单词是否是城市名称之一
                        const cityName = cityNames.find(city => word.includes(city));
                        if (cityName) {
                            return (
                                <span key={index}>
                                    <span style={{ cursor: 'pointer', textDecoration: 'underline', fontSize: '20px' }} onClick={() => handleFixCityClick(cityName)}>
                                        {word}
                                    </span>
                                    {' '}
                                </span>
                            );
                        } else {
                            return <span key={index} style={{ fontSize: '16px' }}>{word} </span>;
                        }
                    })}
                </p> */}
            {/* {renderTextWithParagraphs(text, cityNames)} */}
            {/* </div> */}
            <div style={{ flex: '1 1 40%', padding: '20px', background: '#f7f7f7', borderRadius: '10px', boxShadow: '0 2px 4px rgba(0,0,0,0.1)', margin: '20px', overflowY: 'auto', maxHeight: '100vh' }}>
                <div style={{ flex: 1, overflowY: 'auto', padding: '20px' }}>
                    {renderEventDetails()}
                </div>
                <div style={{ borderTop: '1px solid #ddd', padding: '20px' }}>
                    <form onSubmit={handleChatSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
                        <input
                            type="text"
                            // value={chatInput}
                            value={eventDescription}
                            onChange={e => setEventDescription(e.target.value)}
                            placeholder="Enter Event Name"
                            style={{
                                padding: '10px',
                                marginBottom: '10px',
                                border: '1px solid #ddd',
                                borderRadius: '5px'
                            }}
                        />
                        <button type="submit" style={{
                            padding: '10px',
                            border: 'none',
                            borderRadius: '5px',
                            backgroundColor: '#007BFF',
                            color: 'white',
                            cursor: 'pointer'
                        }}>
                            Add Event
                        </button>
                    </form>
                </div>

            </div>

        </div>
    );
};

export default MapCustom;




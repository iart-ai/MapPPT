// Not used
import React, { useState } from 'react';
import { MapContainer, TileLayer, Polygon, useMap } from 'react-leaflet';

const LeafMapComponent = () => {
  const [selectedArea, setSelectedArea] = useState(null);

  // 示例数据
  const areas = [
    {
      name: "Area 1",
      coordinates: [[37.7, -122.4], [37.8, -122.4], [37.8, -122.5], [37.7, -122.5]],
      population: 26599,
      area: 6.11
    },
    // 其他区域...
  ];

  const handleAreaClick = (area) => {
    setSelectedArea(area);
  };

  return (
    <MapContainer center={[37.7, -122.4]} zoom={13} scrollWheelZoom={true} style={{ height: "100vh" }}>
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {areas.map((area, index) => (
        <Polygon
          key={index}
          positions={area.coordinates}
          eventHandlers={{ click: () => handleAreaClick(area) }}
        />
      ))}
      {/* 根据 selectedArea 显示额外的信息 */}
    </MapContainer>
  );
};

export default LeafMapComponent;

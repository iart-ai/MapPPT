import React, { useState, useEffect } from 'react';
import DeckGL from '@deck.gl/react';
import ReactMapGL from 'react-map-gl';
import { PolygonLayer } from '@deck.gl/layers';
import Select from 'react-select'; // 假设使用 react-select 作为下拉菜单
// 解析 GeoJSON 数据以获取坐标
import { FlyToInterpolator } from '@deck.gl/core';
import OpenAI from "openai";
import { SketchPicker } from 'react-color';

// const openai = new OpenAI({
//     //   apiKey: process.env.OPENAI_API_KEY,
//     apiKey: "",
//     dangerouslyAllowBrowser: true
// });
const openai = ""

// 地图的初始视图状态
const initialViewState = {
    longitude: 9.6659,
    latitude: 48.1627,
    zoom: 7,
    pitch: 0,
    bearing: 0
};


// Don't delete this parese is for the Geojson file!!!
function parseGeoJSON(geoJSONData) {
    const parsedData = {};
    console.log("original geojson",geoJSONData);
    geoJSONData.features.forEach(feature => {
        const countryName = feature.properties.NAME_1; // 或 COUNTRY 根据您的数据结构
        const coordinates = feature.geometry.coordinates;
        // console.log(coordinates)
        // 省略类型检查和数据转换的细节...
        parsedData[countryName] = { coordinates: coordinates[0] }; // 或者其他您需要的格式
    });
    console.log("geojson",parsedData);
    return parsedData;
}
function parseOverpassData(overpassData) {
    // Initialize an empty object to store the parsed data
    const parsedData = {};
    console.log("original overpass", overpassData)
    overpassData.elements.forEach(element => {
        if (element.type === "relation" && element.members) {
            // Assuming the first member with role 'admin_centre' has the place name
            const placeNameMember = element.members.find(member => member.role === 'admin_centre');
            const placeName = placeNameMember ? `Relation ${element.id}` : 'Unknown'; // Use 'Unknown' if no name found

            // Extracting the coordinates from the 'outer' members
            const coordinates = element.members
                .filter(member => member.role === 'outer' && member.geometry)
                .flatMap(member => member.geometry.map(point => [point.lon, point.lat]));

            // Storing the coordinates under the place name
            parsedData[placeName] = { coordinates: [coordinates] };
        }
    });
    console.log("overpass data", parsedData)
    return parsedData;
}



function hexToRGB(hex) {
    let r = parseInt(hex.slice(1, 3), 16);
    let g = parseInt(hex.slice(3, 5), 16);
    let b = parseInt(hex.slice(5, 7), 16);
    return [r, g, b, 100]; // Alpha 值设置为 255
}

function getCentroid(coordinates) {
    // Implement the logic to calculate the centroid from your coordinates
    // For simplicity, let's assume the coordinates are [[longitude, latitude], ...]
    let centroid = { longitude: 0, latitude: 0 };
    coordinates.forEach(coord => {
        centroid.longitude += coord[0];
        centroid.latitude += coord[1];
    });
    centroid.longitude /= coordinates.length;
    centroid.latitude /= coordinates.length;
    return centroid;
}

const MapComponent = () => {
    // DeckGL 和 react-map-gl 需要视图状态来管理用户的交互和地图的视图状态
    const [mapStyle, setMapStyle] = useState('mapbox://styles/mapbox/light-v11');
    const [polygonFillColor, setPolygonFillColor] = useState([255, 0, 0, 100]); // Default color
    const [chatInput, setChatInput] = useState('');
    const [messages, setMessages] = useState([]);
    const [response, setResponse] = useState([]);
    const [locationInput, setLocationInput] = useState('');
    // const handleLocationChange = (event) => {
    //     setLocationInput(event.target.value);
    // };
    const handleChatSubmit = async (e) => {
        e.preventDefault();
        const newMessage = chatInput;

        // Add the new message to the chat history
        setMessages(messages => [...messages, { role: "user", content: newMessage }]);

        try {
            // Asynchronously call identifyRegionsInText to get the matched regions
            const { matchedRegions, responseText } = await identifyRegionsInText(newMessage, countryData);

            // Update the selected regions (this may need adjustment based on your specific logic)
            setSelectedRegions(matchedRegions);

            // Update the chat with the response from ChatGPT
            setMessages(messages => [...messages, { role: "system", content: responseText }]);
        } catch (error) {
            console.error("Error identifying regions: ", error);
            // Handle errors, for example, by displaying an error message
        }

        setChatInput(''); // Clear the input field
    };

    const handleLocationSubmit = async () => {
        // 检查locationInput是否为空
        if (!locationInput.trim()) {
            alert("Please enter a location name.");
            return;
        }

        // 使用Overpass API获取地点的边界数据
        const overpassUrl = `https://overpass-api.de/api/interpreter?data=[out:json][timeout:25];(relation["name"="${locationInput}"];);out geom;`;

        try {
            const response = await fetch(overpassUrl);
            const overpassData = await response.json();

            // 解析数据并设置状态
            // const parsedData = parseGeoJSON(overpassData); //TODO
            const parsedData = parseOverpassData(overpassData)
            //   setBoundaryData(parsedData);
            setCountryData(parsedData);
            // console.log(parsedData)
            // 清空输入框
            setLocationInput('');
        } catch (error) {
            console.error('Error fetching boundary data:', error);
        }
    };

    // 选择background 的颜色
    const [backgroundColor, setBackgroundColor] = useState('#fff');
    const [regionColors, setRegionColors] = useState({});
    const [countryData, setCountryData] = useState({});
    const [selectedRegions, setSelectedRegions] = useState([]);
    const [layers, setLayers] = useState([]);

   


    const [viewState, setViewState] = useState({
        longitude: 8.35,
        latitude: 47.5706,
        zoom: 7,
        pitch: 0,
        bearing: 0
    });

    const handleFillColorChange = (region, color) => {
        setRegionColors(prevColors => ({
            ...prevColors,
            [region]: color.hex
        }));
        updateLayers(region, color.hex);
    };
    const updateLayers = (region, color) => {
        setLayers(prevLayers => {
            // 移除旧的图层
            const newLayers = prevLayers.filter(layer => layer.id !== `polygon-layer-${region}`);
            const regionData = countryData[region];
            const fillColor = hexToRGB(color);
            // 添加新的图层
            const newLayer = new PolygonLayer({
                id: `polygon-layer-${region}`,
                data: [{ contour: regionData.coordinates }],
                pickable: true,
                stroked: true,
                filled: true,
                lineWidthMinPixels: 1,
                getPolygon: d => d.contour,
                getFillColor: fillColor,
                getLineColor: [80, 80, 80],
                getLineWidth: 1
            });
            return [...newLayers, newLayer];
        });
    };
    useEffect(() => {
        // 初始化或更新地区颜色
        const newRegionColors = { ...regionColors };
        selectedRegions.forEach(region => {
            if (!newRegionColors[region]) {
                newRegionColors[region] = '#ff0000'; // 默认颜色
            }
        });
        setRegionColors(newRegionColors);
    }, [selectedRegions]);


    useEffect(() => {
        // fetch('/geoData.json')
        fetch('/export.geojson')
            .then(response => response.json())
            .then(data => {
                const parsedData = parseGeoJSON(data);
                setCountryData(parsedData);
                // setRegionsData(parsedData);
            });
    }, []);
   

    useEffect(() => {
        if (countryData) {
            // 使用boundaryData更新图层
            const newLayers = Object.keys(countryData).map(regionKey => {
                const regionData = countryData[regionKey];
                return new PolygonLayer({
                    id: `polygon-layer-${regionKey}`,
                    data: [{ contour: regionData.coordinates }],
                    pickable: true,
                    stroked: true,
                    filled: true,
                    lineWidthMinPixels: 1,
                    getPolygon: d => d.contour,
                    getFillColor: "blue",
                    // getFillColor: () => polygonFillColor,
                    getLineColor: [80, 80, 80],
                    getLineWidth: 1
                });
            });

            setLayers(newLayers);
        }
    }, [countryData]);

    useEffect(() => {
        const newLayers = selectedRegions.map(regionKey => {
            // const regionData = countryData[regionKey];
            const regionData = countryData[regionKey];
            const fillColor = hexToRGB(regionColors[regionKey] || '#FF0000');
            // setPolygonFillColor = fillColor;
            const centroid = getCentroid(regionData.coordinates);
            setViewState({
                ...viewState,
                // longitude: firstCoord[0], 
                // latitude: firstCoord[1] 
                longitude: centroid.longitude,
                latitude: centroid.latitude,
                zoom: 7, // You can also dynamically set the zoom level based on the region size
                transitionDuration: 1000, // Duration of the transition animation in milliseconds
                transitionInterpolator: new FlyToInterpolator(), // This enables the smooth flying animation
                transitionEasing: d => d, // Optional easing function
            });
            return new PolygonLayer({
                id: `polygon-layer-${regionKey}`,
                data: [{ contour: regionData.coordinates }], // Flatten the coordinates array
                pickable: true,
                stroked: true,
                filled: true,
                lineWidthMinPixels: 1,
                getPolygon: d => d.contour,
                getFillColor: fillColor,
                // getFillColor: () => polygonFillColor,
                getLineColor: [80, 80, 80],
                getLineWidth: 1
            });
        });

        setLayers(newLayers); // Store the generated layers in state
    }, [selectedRegions, polygonFillColor, countryData]);

    return (

        <div style={{ display: 'flex', height: '100vh' }}>
            <div style={{ width: '50%', position: 'relative' }}>
                <DeckGL
                    initialViewState={initialViewState}
                    viewState={viewState}
                    onViewStateChange={({ viewState }) => setViewState(viewState)}
                    controller={true}
                    // layers={[polygonLayer]}
                    layers={layers}
                >
                    <ReactMapGL
                        mapboxApiAccessToken={process.env.REACT_APP_MAPBOX_ACCESS_TOKEN}
                        mapStyle={mapStyle}
                    />
                </DeckGL>
            </div>
            <div style={{ width: '50%', position: 'relative' }}>
                <input
                    type="text"
                    value={locationInput}
                    onChange={(e) => setLocationInput(e.target.value)}
                    placeholder="Enter location name..."
                />
                <button onClick={handleLocationSubmit}>Get Boundary</button>
                <div className="chat-interface">
                    {messages.map((message, index) => (
                        <p key={index} className={message.role}>
                            <strong>{message.role === 'user' ? 'You' : 'Bot'}:</strong> {message.content}
                        </p>
                    ))}
                    <form onSubmit={handleChatSubmit}>
                        <input
                            type="text"
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            placeholder="Type your message here..."
                        />
                        <button type="submit">Send</button>
                    </form>
                </div>
                {/* 地区选择和颜色选择 */}
                <div className="region-color-selector"></div>
                <h1>Please select the location</h1>
                <Select
                    isMulti // enable multi-select
                    options={Object.keys(countryData).map(key => ({ value: key, label: key }))}
                    // onChange={option => setSelectedCountry(option.value)}
                    // onChange={handleRegionChange}
                    onChange={options => setSelectedRegions(options.map(option => option.value))}
                // onChange={options => setSelectedRegions(options ? options.map(option => option.value) : [])}
                />
                {/* <div className="chat-interface">
                    {messages.map((message, index) => (
                        <p key={index}>
                        <strong>{message.role}:</strong> {message.content}
                      </p>
                    ))}
                    <form onSubmit={handleChatSubmit}>
                        <input
                            type="text"
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                        />
                        <button type="submit">Send</button>
                    </form>
                    <div>{response}</div>
                </div> */}


                {selectedRegions.map(region => (
                    <div key={region}>
                        <h2>{`Select color for ${region}`}</h2>
                        <SketchPicker
                            color={regionColors[region]}
                            onChangeComplete={color => handleFillColorChange(region, color)}
                        />
                    </div>
                ))}

            </div>
        </div>
    );
};
// async function identifyRegionsInText(text, countryData) {
//     try {
//         const chatCompletion = await openai.chat.completions.create({
//             messages: [{ role: "user", content: text }],
//             model: "gpt-3.5-turbo",
//         });

//         const responseText = chatCompletion?.choices[0]?.message?.content || "";
//         // 这里需要一个逻辑来从 responseText 中提取地理位置
//         // 然后返回匹配的地区列表
//         // 下面是一个简单的示例，实际上可能需要更复杂的逻辑
//         const matchedRegions = [];
//         Object.keys(countryData).forEach(region => {
//             if (responseText.includes(region)) {
//                 matchedRegions.push(region);
//             }
//         });
//         console.log("responseText", responseText)
//         return matchedRegions;
//     } catch (error) {
//         console.error("Error in identifyRegionsInText:", error);
//         return [];
//     }
// }
async function identifyRegionsInText(text, countryData) {
    try {
        const chatCompletion = await openai.chat.completions.create({
            messages: [{ role: "user", content: text }],
            model: "gpt-3.5-turbo",
        });

        const responseText = chatCompletion?.choices[0]?.message?.content || "";
        const matchedRegions = Object.keys(countryData).filter(region => responseText.includes(region));
        console.log("responseText", responseText);

        // Return both the responseText and the matchedRegions in an object
        return {
            matchedRegions: matchedRegions,
            responseText: responseText
        };
    } catch (error) {
        console.error("Error in identifyRegionsInText:", error);
        return {
            matchedRegions: [],
            responseText: ''
        };
    }
}



export default MapComponent;


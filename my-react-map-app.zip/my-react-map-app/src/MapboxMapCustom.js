import React, { useEffect } from 'react';
import mapboxgl from 'mapbox-gl';
import df from './WFIGS_Current_Interagency_Fire_Perimeters.geojson'; // 更新为你的GeoJSON文件的正确路径

// 设置你的Mapbox访问令牌
mapboxgl.accessToken = process.env.REACT_APP_MAPBOX_ACCESS_TOKEN;

const MapboxMapCustom = () => {
  useEffect(() => {
    const map = new mapboxgl.Map({
      container: 'mapbox-map', // 容器ID
      style: 'https://tiles.stadiamaps.com/styles/alidade_smooth.json', // 使用你选择的样式
      center: [-101.87135134451694, 36.258603171742294],
      zoom: 4.430411259997386,
    });

    map.on('load', () => {
      map.addSource('df__1', {
        type: 'geojson',
        data: df,
      });

      map.addLayer({
        id: 'df__1',
        source: 'df__1',
        type: 'circle',
        paint: {
          'circle-color': '#616f1e',
          'circle-radius': 2,
          'circle-opacity': 0.05,
          'circle-stroke-color': '#a7ac91',
          'circle-stroke-width': 1,
        },
      });
    });
  }, []);

  return <div id="mapbox-map" style={{ width: '100%', height: '400px' }} />;
};

export default MapboxMapCustom;

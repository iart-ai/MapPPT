// Not used
import React from 'react';
import { GoogleMap, LoadScript } from '@react-google-maps/api';
import geoJsonData from "/ihome/hdaqing/yuj49/.mozilla/iArt/my-react-map-app/public/gadm41_ALB_1.json";
// import Fra
import { GoogleMap, LoadScript, Data } from '@react-google-maps/api';

const containerStyle = {
  width: '50%',
  height: '50%'
};

const center = {
  lat: 0,
  lng: 0
};
const zoom = 2;
const GoogleMapComponent = () => {
  return (
    <LoadScript googleMapsApiKey="q1XONlfGB6NpnwDBF2mFf7jNqls=">
      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        zoom={2}
      >
        {geoJsonData && (
          <Data
            options={{
              // Define style and other options as needed
            }}
            onLoad={data => {
              data.addGeoJson(geoJsonData);
            }}
          />
        )}
      </GoogleMap>
    </LoadScript>
  );
}

export default GoogleMapComponent;

// import React from 'react';
// import MapComponent from './MapComponent';
// // import geojsonData from './gadm41_ALB_1.json'; // 替换为您的 GeoJSON 数据路径

// function App() {
//   return (
//     <div>
//       <MapComponent/>
//     </div>
//   );
// }

// export default App;
import React, { useState } from 'react';
// import MapComponent from './MapComponent';
// import MapDefault from './MapDefault';
import MapCustom  from './MapCustom';
import LangchainOutline from './LangchainOutline';
function App() {
  return (
    <div>
      <MapCustom/>
      {/* <LangchainOutline/> */}
    </div>
  );
}



// function App() {
//   const [searchQuery, setSearchQuery] = useState('');
//   const [searchResults, setSearchResults] = useState(null);

//   async function fetchBingSearchResults(query) {
//     try {
//       const response = await fetch(`http://localhost:4000/bing-search?q=${encodeURIComponent(query)}`);
//       if (!response.ok) {
//         throw new Error(`Network response was not ok, status: ${response.status}`);
//       }
//       console.log(response)
//       const contentType = response.headers.get("content-type");
//       if (!contentType || !contentType.includes("application/json")) {
//         throw new Error("Received non-JSON response");
//       }
//       return await response.json();
//     } catch (error) {
//       console.error('Error fetching Bing search results:', error);
//       throw error; // 抛出错误以便可以在调用函数的地方处理
//     }
//   }


//   const handleSearch = async () => {
//     const results = await fetchBingSearchResults(searchQuery);
//     setSearchResults(results);
//   };

//   return (
//     <div style={{ height: '100vh', width: '100%', padding: '20px' }}>
//       <div style={{ marginBottom: '10px' }}>
//         <input
//           type="text"
//           value={searchQuery}
//           onChange={(e) => setSearchQuery(e.target.value)}
//           style={{ marginRight: '10px', padding: '10px' }}
//         />
//         <button onClick={handleSearch} style={{ padding: '10px' }}>Search</button>
//       </div>
//       {searchResults && (
//         <div>
//           <h3>Search Results:</h3>
//           {/* 简单展示搜索结果，根据您的数据结构可能需要调整 */}
//           <pre>{JSON.stringify(searchResults, null, 2)}</pre>
//         </div>
//       )}
//     </div>
//   );
// }

export default App;

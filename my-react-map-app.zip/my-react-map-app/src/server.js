const express = require('express');
const axios = require('axios');
const app = express();
const cors = require('cors'); 
app.use(cors());

const BING_API_KEY = '';

app.get('/bing-search', async (req, res) => {
    const searchTerm = req.query.q;
    console.log("Received search term:", searchTerm);

    try {
        const response = await axios.get(`https://api.bing.microsoft.com/v7.0/search?q=${encodeURIComponent(searchTerm)}`, {
            headers: { 'Ocp-Apim-Subscription-Key': BING_API_KEY }
        });
        console.log("Content-Type:", response.headers['content-type']); // 打印内容类型
        console.log("Response:", response.data); // 打印响应内容
        res.json(response.data);
        console.log("")
    } catch (error) {
        console.error("Error occurred while fetching data from Bing Search API:", error);
        res.status(500).send('Error occurred while fetching data from Bing Search API');
    }
});

const PORT = 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

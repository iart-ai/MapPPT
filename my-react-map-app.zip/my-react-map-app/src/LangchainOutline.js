import React, { useState } from 'react';
import { createStructuredOutputRunnable } from "langchain/chains/openai_functions";
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { JsonOutputFunctionsParser } from "langchain/output_parsers";

function LangchainOutline() {
  const [eventDescription, setEventDescription] = useState('');
  const [eventDetails, setEventDetails] = useState({ events: [] });
  const [combinedDetails, setCombinedDetails] = useState('');


  const handleDescriptionChange = (event) => {
    setEventDescription(event.target.value);
  };

  const fetchEventDetails = async () => {
    const jsonSchema = {
      title: "EventDetails",
      description: `You are a Wikipedia writer.
              You have gathered information from experts and search engines.
              Now, you are refining the outline and detail of the Wikipedia page.
              Write an outline and detail for a Wikipedia page about the user-provided topic: Be comprehensive and specific.
              
              Structure your response as follows:
              Event1: [Event Name]
              Location1: [Specific City ], [Country]
              Date1: [Month Day, Year] or [Month Day, Year - Month Day, Year]
              Background1: [Background information related to the event ]
              MainEvent1: [Key actions or occurrences in the event]
              Result1: [Outcome or conclusion of the event]
              Description1: [Detailed explanation of the event's direct connection and significance to the event ]
              You need to generate more than 5 examples.
              `,
      type: "object",  // 确保最外层是 object 类型
      properties: {
        events: {  // 使用一个数组属性来存储多个事件
          type: "array",
          items: {
            type: "object",
            properties: {
              city: { type: "string" },
              country: { type: "string" },
              date: { type: "string" },
              background: { type: "string" },
              mainEvent: { type: "string" },
              result: { type: "string" },
              description: { type: "string" },
            },
            required: ["city", "country", "date", "background", "mainEvent", "result", "description"],
          },
        },
      },
      required: ["events"],
    };

    const model = new ChatOpenAI({ openAIApiKey: "", });
    
    const prompt = ChatPromptTemplate.fromMessages([
      ["human", "Event description: {description}"],
    ]);

    const outputParser = new JsonOutputFunctionsParser();

    const runnable = createStructuredOutputRunnable({
      outputSchema: jsonSchema,
      llm: model,
      prompt,
      outputParser
    });

    const response = await runnable.invoke({ description: eventDescription });
    console.log("response", response)
    setEventDetails(response);

  };

  const fetchAndGenerateDetails = async () => {
    // JSON Schema 和 LangChain 调用逻辑来获取事件详情...
    await fetchEventDetails();  
    // 假设 `fetchEventDetails` 函数已经执行，并且我们现在有了所有事件的数据
    const allEventsDetails = eventDetails.events.map(event => 
      `${event.city}, ${event.country} on ${event.date}: ${event.description}`
    ).join(' ');
    
    // const model = new ChatOpenAI({ openAIApiKey: "", });
    
    const comprehensivePrompt = `Given these events: ${allEventsDetails}, describe the overall background, the sequence of events, and the consequences connecting these events.`;
   
    const prompt = ChatPromptTemplate.fromMessages([
      ["system", comprehensivePrompt]
    ]);

    const outputSchema = {
      title: "ComprehensiveEventDetails",
      description: "A comprehensive description covering all events and their connections.",
      type: "object",  // 输出是一个对象
      properties: {
        comprehensiveDescription: {  // 这个属性将包含综合描述
          type: "array",
          items:{
            type:"object",
            properties: {
              background:{type:"string"},
              sequence: {type:"string"},
              description:{type:"string"},
              result:{type:"string"},
            },
          required: ["background", "sequence", "description","result"]
          }
          // description: "A detailed description of all events and their interrelations."
        }
      },
      required: ["comprehensiveDescription"]  // 这个属性是必需的
    };
    const outputParser = new JsonOutputFunctionsParser();
    const runnable = createStructuredOutputRunnable({
      outputSchema: outputSchema,
      llm: model,
      prompt,
      outputParser
    });
    
    // 使用 LangChain 生成综合背景和结果描述
    const response = await runnable.invoke({ description: comprehensivePrompt });
    console.log("response from the generation result", response)
    setCombinedDetails(response.comprehensiveDescription);
  };
  return (
    <div>
      <h1>Event Details Fetcher</h1>
      <textarea
        value={eventDescription}
        onChange={handleDescriptionChange}
        placeholder="Describe the event here..."
      ></textarea>
      <button onClick={fetchAndGenerateDetails}>Get Combined Event Details</button>
      {/* {combinedDetails && (
      <div>
        <h2>Combined Event Information:</h2>
        <p>Background: {combinedDetails.background}</p>
        <p>Sequence of Events: {combinedDetails.sequence}</p>
        <p>Description: {combinedDetails.description}</p>
        <p>Result: {combinedDetails.result}</p>
      </div>
    )} */}
    <div>
    {eventDetails.events && eventDetails.events.map((event, index) => (
        <div key={index}>
          <h2>Event {index + 1} Information:</h2>
          <p>City: {event.city}</p>
          <p>Country: {event.country}</p>
          <p>Date: {event.date}</p>
          <p>Background: {event.background}</p>
          <p>Main Event: {event.mainEvent}</p>
          <p>Result: {event.result}</p>
          <p>Description: {event.description}</p>
        </div>
      ))}
</div>

    {combinedDetails && combinedDetails.map((detail, index) => (
  <div key={index}>
    <h2>Overall information</h2>
    <p>Background: {detail.background}</p>
    <p>Sequence of Events: {detail.sequence}</p>
    <p>Description: {detail.description}</p>
    <p>Result: {detail.result}</p>
  </div>
))}
</div>
  );
}

export default LangchainOutline;

import React, { useState, useEffect } from 'react';
import DeckGL from '@deck.gl/react';
import ReactMapGL from 'react-map-gl';
import * as turf from '@turf/turf';
import { PolygonLayer } from '@deck.gl/layers';
import { TextLayer } from '@deck.gl/layers';

import Select from 'react-select'; // 假设使用 react-select 作为下拉菜单
// 解析 GeoJSON 数据以获取坐标
import { FlyToInterpolator } from '@deck.gl/core';
import OpenAI from "openai";
// import localGeoJson from '/gadm41_FRA_2.json'; // 本地GeoJSON文件的路径

const openai = ""
// new OpenAI({
//     //   apiKey: process.env.OPENAI_API_KEY,
//     apiKey: "",
//     dangerouslyAllowBrowser: true
// });
async function sendToOpenAI(inputText) {
    try {
        const chatCompletion = await openai.chat.completions.create({
            messages: [{ role: "user", content: inputText }],
            model: "gpt-3.5-turbo",
        });

        const responseText = chatCompletion?.choices[0]?.message?.content || "";


        // Extract and return the text from the response
        return responseText;
    } catch (error) {
        console.error("Error communicating with OpenAI:", error);
        return "Sorry, I couldn't process that.";
    }
}

// 地图的初始视图状态
const initialViewState = {
    longitude: 9.6659,
    latitude: 48.1627,
    zoom: 10,
    pitch: 0,
    bearing: 0
};

function getFirstCoordinate(coordinates) {
    // Return the first set of coordinates from the data.
    // Assuming that 'coordinates' is an array of arrays like [[lon, lat], [lon, lat], ...].
    if (coordinates.length > 0 && coordinates[0].length > 0) {
        return { longitude: coordinates[0][0], latitude: coordinates[0][1] };
    }
    return { longitude: 0, latitude: 0 }; // Default to (0,0) if no coordinates are present.
}


function getCentroid(coordinates) {
    let validCoordinates = coordinates.filter(coord => coord && coord.length >= 2 && !isNaN(coord[0]) && !isNaN(coord[1]));

    // 如果没有有效坐标，则返回一个默认值或第一个坐标
    if (validCoordinates.length === 0) {
        return coordinates[0] && coordinates[0].length >= 2
            ? { longitude: coordinates[0][0][0], latitude: coordinates[0][0][1] }
            : { longitude: 0, latitude: 0 }; // 或者返回一个全局的默认位置
    }

    let centroid = { longitude: 0, latitude: 0 };
    validCoordinates.forEach(coord => {
        centroid.longitude += coord[0];
        centroid.latitude += coord[1];
    });

    centroid.longitude /= validCoordinates.length;
    centroid.latitude /= validCoordinates.length;

    return centroid;
}


const MapDefault = () => {
    const [chatInput, setChatInput] = useState('');
    const [chatHistory, setChatHistory] = useState([]);
    const [viewState, setViewState] = useState(initialViewState);
    const [boundaryData, setBoundaryData] = useState([]);
    const [layers, setLayers] = useState([]);
    const timelineLocations = ['Paris', 'Berlin', 'GreaterLondon']; // Example timeline
    const [dataSource, setDataSource] = useState('local');
    const [mentionedLocations, setMentionedLocations] = useState([]);
    const [selectedEvent, setSelectedEvent] = useState(null);
    const [selectedEventSet, setSelectedEventSet] = useState('WWII'); // 默认设置为第二次世界大战的事件
    const [activeLocationIndex, setActiveLocationIndex] = useState(0);
    const [locationColors, setLocationColors] = useState({});
    const [customEvents, setCustomEvents] = useState([]);

    // 更新地点颜色映射，为新地点分配颜色
    const updateLocationColors = () => {
        const newLocationColors = { ...locationColors };
        mentionedLocations.forEach(location => {
            if (!newLocationColors[location]) {
                newLocationColors[location] = generateRandomPastelColor();
            }
        });
        setLocationColors(newLocationColors);
    };
    useEffect(() => {
        updateLocationColors();
        // 依赖于提及的地点列表
    }, [mentionedLocations]);

    function handleEventSelect(option) {
        setSelectedEvent(option.value);
    }

    // 处理自定义事件表单的提交
    const handleCustomEventSubmit = (e) => {
        e.preventDefault();
        const eventName = e.target.eventName.value.trim();
        if (eventName) {
            setCustomEvents(prevEvents => [...prevEvents, eventName]);
            e.target.eventName.value = ''; // 清空输入框
        }
    };

    const moveToNextLocation = () => {
        if (mentionedLocations.length > 0) {
            const nextIndex = (activeLocationIndex + 1) % mentionedLocations.length;
            setActiveLocationIndex(nextIndex);
            const nextLocation = mentionedLocations[nextIndex];
            updateViewForLocation(nextLocation); // 更新地图视图
        }
    };
    // 在 useEffect 中更新地图视图
    useEffect(() => {
        if (mentionedLocations.length > 0 && mentionedLocations[activeLocationIndex]) {
            const activeLocation = mentionedLocations[activeLocationIndex];
            updateViewForLocation(activeLocation);
        }
    }, [activeLocationIndex, mentionedLocations]);


    const eventDictionary = {
        wwiiEvents: "World War II",
        iraqWarEvents: "Iraq War",
        firstWorldWarEvents: "World War I",
        coldWarEvents: "Cold War",
        ancientEvents: "Ancient Events",
        // 添加更多的事件映射...
    };

    // Send the new prompt to chatgpt as prompt 
    function generatePromptForEvent(eventArrayName) {
        const eventName = eventDictionary[eventArrayName];
        return `Describe the historical significance of the ${eventName}, Please generate the city location which relate to the descirbtion .`;
    }
    function generateRandomPastelColor() {
        const hue = Math.floor(Math.random() * 360);
        const saturation = Math.floor(Math.random() * (100 - 55) + 55); // 保持饱和度不过低
        const lightness = Math.floor(Math.random() * (100 - 85) + 85); // 保持亮度较高
        return `hsl(${hue},${saturation}%,${lightness}%)`;
    }
    // console.log("generateRandomPastelColor()", generateRandomPastelColor());

    const wwiiEvents = [
        { location: 'London', country: 'United Kingdom', event: 'The Blitz', date: '1940-09-07', description: 'A major German bombing campaign against the United Kingdom during the Second World War.' },
        { location: 'Paris', country: 'France', event: 'Liberation of Paris', date: '1944-08-25', description: 'The military action that liberated Paris from Nazi Germany during the Second World War.' },
        { location: 'Berlin', country: 'Germany', event: 'Battle of Berlin', date: '1945-04-20', description: 'One of the final battles of the European theatre during the Second World War.' },
        { location: 'Pearl Harbor', country: 'United States', event: 'Attack on Pearl Harbor', date: '1941-12-07', description: 'A surprise military strike by the Imperial Japanese Navy against the United States naval base.' },
        { location: 'Stalingrad', country: 'Soviet Union', event: 'Battle of Stalingrad', date: '1942-08-23', description: 'A major confrontation of World War II in which Nazi Germany and its allies fought the Soviet Union for control of the city of Stalingrad.' },
        { location: 'Hiroshima', country: 'Japan', event: 'Hiroshima Atomic Bombing', date: '1945-08-06', description: 'The United States dropped an atomic bomb on the city of Hiroshima, which was a significant event leading to the end of World War II.' },
        { location: 'Normandy', country: 'France', event: 'D-Day Normandy Invasion', date: '1944-06-06', description: 'The Allied invasion of Normandy in Operation Overlord during World War II.' },
        { location: 'Warsaw', country: 'Poland', event: 'Warsaw Uprising', date: '1944-08-01', description: 'A major World War II operation by the Polish resistance Home Army to liberate Warsaw from German occupation.' },
        { location: 'Dresden', country: 'Germany', event: 'Bombing of Dresden', date: '1945-02-13', description: 'An Allied bombing raid on the city of Dresden, which created a firestorm and destroyed the city center.' },

    ];
    const [currentEvents, setCurrentEvents] = useState(wwiiEvents);
    const [userEvents, setUserEvents] = useState([]); // 存储用户事件
    const [eventInput, setEventInput] = useState({ location: '', country: '', event: '', date: '', description: '' }); // 用户输入

    const iraqWarEvents = [
        { location: 'Baghdad', country: 'Iraq', event: 'Fall of Baghdad', date: '2003-04-09', description: 'The capture of the capital of Iraq by American forces marked a pivotal moment in the Iraq War.' },
        { location: 'Basra', country: 'Iraq', event: 'Battle of Basra', date: '2003-03-21', description: 'An early battle in the Iraq War that resulted in the coalition taking control of the city.' },
        { location: 'Fallujah', country: 'Iraq', event: 'First Battle of Fallujah', date: '2004-04-04', description: 'A major battle fought between the U.S. Marines and the Iraqi insurgency in the city of Fallujah.' },
        // ...更多事件...
    ];
    const firstWorldWarEvents = [
        { location: 'Sarajevo', country: 'Bosnia', event: 'Assassination of Archduke Franz Ferdinand', date: '1914-06-28', description: 'The event that triggered the outbreak of World War I.' },
        { location: 'Somme', country: 'France', event: 'Battle of the Somme', date: '1916-07-01', description: 'One of the largest battles of the First World War, known for its heavy casualties.' },
        { location: 'Verdun', country: 'France', event: 'Battle of Verdun', date: '1916-02-21', description: 'The longest single battle of World War I.' },
        // ...其他事件...
    ];
    const coldWarEvents = [
        { location: 'Berlin', country: 'Germany', event: 'Berlin Blockade', date: '1948-06-24', description: 'The first major international crisis of the Cold War.' },
        { location: 'Cuba', country: 'Cuba', event: 'Cuban Missile Crisis', date: '1962-10-16', description: 'A 13-day confrontation between the United States and the Soviet Union over Soviet ballistic missiles deployed in Cuba.' },
        { location: 'Afghanistan', country: 'Afghanistan', event: 'Soviet-Afghan War', date: '1979-12-24', description: 'A conflict where Soviet forces fought against Afghan insurgents supported by the US.' },
        // ...其他事件...
    ];
    const ancientEvents = [
        { location: 'Rome', country: 'Italy', event: 'Fall of the Roman Empire', date: '476-09-04', description: 'The event marking the end of the Western Roman Empire and the beginning of the Middle Ages.' },
        { location: 'Greece', country: 'Greece', event: 'Battle of Thermopylae', date: '480 BC', description: 'A famous battle in the Persian Wars where a small Greek force faced a much larger Persian army.' },
        { location: 'Egypt', country: 'Egypt', event: 'Construction of the Great Pyramids', date: '2580-2560 BC', description: 'One of the most significant architectural achievements of ancient Egypt.' },
        // ...其他事件...
    ];
    function handleInputChange(e) {
        const { name, value } = e.target;
        setEventInput({ ...eventInput, [name]: value });
    }

    const switchEventSet = (selectedOption) => {
        const eventSetName = selectedOption.value;
        setSelectedEventSet(eventSetName); // 更新当前选中的事件集
        if (eventSetName === 'WWII') {
            setCurrentEvents(wwiiEvents);
        } else if (eventSetName === 'IraqWar') {
            setCurrentEvents(iraqWarEvents);
        } else if (eventSetName === 'WWI') {
            setCurrentEvents(firstWorldWarEvents);
        } else if (eventSetName === 'ColdWar') {
            setCurrentEvents(coldWarEvents);
        }
        else if (eventSetName === 'Ancient') {
            setCurrentEvents(ancientEvents);
        }
        // 重置所选事件
        setSelectedEvent(null);
        // setCurrentEvents(null);
    };



    const countryColors = {
        'United Kingdom': [255, 200, 0], // 黄色
        'France': [0, 0, 255],           // 蓝色
        'Germany': [255, 0, 0],          // 红色
        // ... 其他国家颜色
    };
    // 在 MapComponent 内部

    const extractLocationsFromText = (text) => {
        const locations = currentEvents.map(event => event.location); // Extend this list as needed
        return locations.filter(location => text.includes(location));
    };
    // Function to handle chat input submission
    const handleChatSubmit = async (e) => {
        e.preventDefault();
        console.log("CurrentEvents", currentEvents)
        const eventPrompt = currentEvents ? generatePromptForEvent(currentEvents) : '';
        const fullPrompt = `${eventPrompt}\n\n${chatInput}`;
        console.log("fullPrompt", fullPrompt)
        const response = await sendToOpenAI(fullPrompt);
        updateLocationColors();
        // Send input to OpenAI and receive response
        // const response = await sendToOpenAI(chatInput);
        setChatHistory([...chatHistory, { user: 'You', text: chatInput }, { user: 'AI', text: response }]);
        setChatInput('');
        // handleChatResponse(response);
        const newLocations = extractLocationsFromText(response);
        const updatedMentionedLocations = [...new Set([...mentionedLocations, ...newLocations])];
        setMentionedLocations(updatedMentionedLocations);
        // const mentionedLocations = extractLocationsFromText(response);

        for (const location of updatedMentionedLocations) {
            await updateViewForLocation(location);
        }
    };

    async function handleEventSubmit(e) {
        e.preventDefault();
        const newEvent = { ...eventInput };
        // 可以在这里添加 ChatGPT 的调用来丰富或验证事件信息
        const gptResponse = await sendToOpenAI(`Tell me about ${newEvent.event} in ${newEvent.location}`);
        console.log("gptResponse",gptResponse)
        newEvent.gptDescription = gptResponse;
        setUserEvents([...userEvents, newEvent]);
        setEventInput({ location: '', country: '', event: '', date: '', description: '' }); // 重置输入
    }

    const hexToRGB = (hex) => {
        let r = parseInt(hex.slice(1, 3), 16);
        let g = parseInt(hex.slice(3, 5), 16);
        let b = parseInt(hex.slice(5, 7), 16);
        return [r, g, b, 100];
    };

    function closePolygonCoordinates(coordinates) {
        if (coordinates.length === 0) {
            return coordinates;
        }
        // 检查多边形是否已经闭合
        const firstPoint = coordinates[0];
        const lastPoint = coordinates[coordinates.length - 1];
        if (firstPoint[0] !== lastPoint[0] || firstPoint[1] !== lastPoint[1]) {
            // 如果没有闭合，则添加第一个点到末尾
            coordinates.push(firstPoint);
        }
        return coordinates;
    }

    function removeDuplicateBoundaries(boundaries) {
        return boundaries.map(boundary => {
            // 确保坐标闭合
            const closedBoundary = closePolygonCoordinates(boundary);
            // 将坐标数组转换为turf的多边形
            let poly = turf.polygon([closedBoundary]);
            // 使用turf简化多边形
            let simplifiedPoly = turf.simplify(poly, { tolerance: 0.005, highQuality: true });
            // 返回简化后的多边形的坐标
            return simplifiedPoly.geometry.coordinates;
        });
    }

    const fetchBoundaryData = async (location) => {
        if (dataSource === 'overpass') {
            const query = `[out:json];(relation["name"="${location}"];);out geom;`;
            const overpassUrl = `https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`;

            try {
                const response = await fetch(overpassUrl);
                const data = await response.json();
                let boundaries = data.elements
                    .filter((element) => element.type === 'relation')
                    .map((relation) => relation.members
                        .filter((member) => member.role === 'outer' && member.geometry)
                        .flatMap((member) => member.geometry.map((point) => [point.lon, point.lat]))
                    )
                    .filter((boundary) => boundary.length > 0);
                let uniqueBoundaries = removeDuplicateBoundaries(boundaries);
                // console.log("uniqueBoundaries", uniqueBoundaries)
                return uniqueBoundaries;

            } catch (error) {
                console.error('Error fetching boundary data:', error);
                return [];
            }
        } else if (dataSource === 'local') {
            // 这里过滤本地GeoJSON数据以找到与 location 匹配的特征
            try {

                const apiBaseUrl = 'https://still-ravine-97463-ab61cc4df1cf.herokuapp.com';

                const response = await fetch(`${apiBaseUrl}/getBoundary?location=${encodeURIComponent(location)}`);
                if (!response.ok) {
                    throw new Error(`Error fetching boundary data for ${location}: ${response.statusText}`);
                }

                const data = await response.json();
                // return data;
                return { location, data };
            } catch (error) {
                console.error('Error fetching local GeoJSON data:', error);
                return [];
            }
        }
    };

    const updateViewForLocation = async (location) => {
        const newBoundary = await fetchBoundaryData(location);
        console.log("newBoundary in the update ", newBoundary)
        const coordinates = newBoundary?.data?.coordinates ?? [];
        if (coordinates.length > 0) {
            // if (newBoundary.data.coordinates.length > 0) {
            const centroid = getCentroid(newBoundary.data.coordinates[0]);
            console.log("newBoundary.data.coordinates centrole", centroid)
            // 设置新的viewState以便地图聚焦到这个中心点
            setViewState({
                ...viewState,
                longitude: centroid.longitude,
                latitude: centroid.latitude,
                zoom: 10,
                transitionDuration: 1000,
                transitionInterpolator: new FlyToInterpolator(),
            });
        }

        setBoundaryData(prevBoundaries => {
            // Check if the location already exists in the boundaryData
            const existingIndex = prevBoundaries.findIndex(b => b.location === newBoundary.location);
            if (existingIndex !== -1) {
                // Replace the existing boundary data for this location
                return [
                    ...prevBoundaries.slice(0, existingIndex),
                    newBoundary,
                    ...prevBoundaries.slice(existingIndex + 1)
                ];
            } else {
                // Add the new boundary data
                return [...prevBoundaries, newBoundary];
            }
        });
    };
    useEffect(() => {
        // 检查 boundaryData 是否为数组并且包含有效数据
        if (Array.isArray(boundaryData) && boundaryData.every(b => b.data && b.data.type === 'MultiPolygon')) {
            const newLayers = boundaryData.flatMap(boundaryItem => {
                // 从 mentionedLocations 中提取当前地点
                const currentLocation = mentionedLocations.find(loc => loc === boundaryItem.location);
                // 获取与当前地点关联的颜色
                const fillColor = locationColors[currentLocation] ? hexToRGB(locationColors[currentLocation]) : [255, 0, 0, 100]; // 使用预先分配的颜色或默认颜色
                console.log("locationColors", locationColors)
                // 为每个多边形数据创建图层
                return boundaryItem.data.coordinates.flatMap(polygon => {
                    const outerBoundary = polygon[0];
                    if (!outerBoundary || outerBoundary.some(coord => !Array.isArray(coord) || coord.length !== 2)) {
                        console.error('Invalid outer boundary for a polygon');
                        return [];
                    }
                    const layerId = `polygon-layer-${boundaryItem.location}`;
                    return new PolygonLayer({
                        id: layerId,
                        data: [{ coordinates: outerBoundary }],
                        pickable: true,
                        stroked: true,
                        filled: true,
                        lineWidthMinPixels: 1,
                        getPolygon: d => d.coordinates,
                        getFillColor: fillColor, // 使用与文本中相同的颜色
                        getLineColor: [255, 255, 255],
                        getLineWidth: 1,
                    });
                });
            });
            setLayers(newLayers);
        }
    }, [boundaryData, locationColors]);

    const startTimeline = () => {
        // setCurrentTimelineIndex(0);
        updateViewForLocation(timelineLocations[0]);
    };
    // Start the timeline automatically when the component mounts
    useEffect(() => {
        startTimeline();
    }, []);
    return (
        <div style={{ display: 'flex', height: '100vh', flexWrap: 'wrap' }}>
            <div style={{ flex: '1 1 50%', minHeight: '50vh', position: 'relative' }}>
                <DeckGL
                    initialViewState={initialViewState}
                    viewState={viewState}
                    onViewStateChange={({ viewState }) => setViewState(viewState)}
                    controller={true}
                    layers={layers}
                >
                    <ReactMapGL
                        mapboxApiAccessToken={process.env.REACT_APP_MAPBOX_ACCESS_TOKEN}
                        mapStyle="mapbox://styles/mapbox/light-v11"
                    />
                </DeckGL>
            </div>
            
            <div style={{ flex: '1 1 50%', minHeight: '50vh', padding: '20px', boxSizing: 'border-box', position: 'relative' }}>
                
                <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', padding: '10px', boxSizing: 'border-box' }}>
                    <Select
                        value={selectedEventSet ? { value: selectedEventSet, label: selectedEventSet } : null}
                        onChange={switchEventSet}
                        options={[
                            { value: 'WWII', label: 'World War II' },
                            { value: 'IraqWar', label: 'Iraq War' },
                            { value: 'WWI', label: 'World War I' },
                            { value: 'ColdWar', label: 'Cold War' },
                            { value: 'Ancient', label: 'Ancient Events' },
                            // 添加更多选项...
                        ]}
                        placeholder="Select event set..."
                    />
                </div>
                <div style={{ marginTop: '60px' }}>

                    <form onSubmit={handleChatSubmit} style={{ display: 'flex', marginBottom: '20px' }}>
                        <input
                            type="text"
                            value={chatInput}
                            onChange={e => setChatInput(e.target.value)}
                            style={{
                                flexGrow: 1,
                                marginRight: '10px',
                                padding: '10px',
                                borderRadius: '20px',
                                border: '1px solid #ddd'
                            }}
                            placeholder="Ask about a historical event..."
                        />
                        <button
                            type="submit"
                            style={{
                                padding: '10px 20px',
                                borderRadius: '20px',
                                border: 'none',
                                backgroundColor: '#007BFF',
                                color: 'white',
                                cursor: 'pointer'
                            }}
                        >
                            Send
                        </button>
                    </form>
                    <button onClick={moveToNextLocation} style={{ /* 添加所需样式 */ }}>
                        Next Location
                    </button>
                    <div style={{
                        overflowY: 'auto',
                        maxHeight: 'calc(80vh - 60px)', // Adjust height based on the Select height
                        border: '1px solid #ddd',
                        borderRadius: '10px',
                        padding: '10px',
                        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
                        marginTop: '10px' // Add some space between the form and history
                    }}>

                        {chatHistory.map((message, index) => {
                            // 使用一个临时的元素来渲染HTML，从而不直接使用dangerouslySetInnerHTML
                            const tempDiv = document.createElement("div");
                            tempDiv.innerHTML = message.text;

                            mentionedLocations.forEach(location => {
                                const locationColor = locationColors[location] || generateRandomPastelColor();
                                // 更新颜色映射以持久化生成的颜色
                                if (!locationColors[location]) {
                                    const newLocationColors = { ...locationColors, [location]: locationColor };
                                    setLocationColors(newLocationColors);
                                }

                                // 使用正则表达式全局匹配地点名称
                                const regex = new RegExp(location, "gi");
                                tempDiv.innerHTML = tempDiv.innerHTML.replace(regex, (matched) =>
                                    `<span style="background-color: ${locationColor};">${matched}</span>`
                                );
                            });

                            return (
                                <div key={index} style={{
                                    margin: '10px 0',
                                    padding: '10px',
                                    borderRadius: '10px',
                                    borderLeft: message.user === 'You' ? '3px solid #007BFF' : '3px solid #34C759'
                                }}>
                                    <b>{message.user}:</b> <span dangerouslySetInnerHTML={{ __html: tempDiv.innerHTML }} />
                                </div>
                            );
                        })}



                    </div>
                </div>
            </div>

            <div style={{ position: 'absolute', zIndex: 1, background: 'white', padding: '10px' }}>
                <label>
                    Select Data Source:
                    <select value={dataSource} onChange={e => setDataSource(e.target.value)}>
                        <option value="local">Local GeoJSON</option>
                        <option value="overpass">Overpass API</option>
                    </select>
                </label>
            </div>
        </div>
    );
};

export default MapDefault;

